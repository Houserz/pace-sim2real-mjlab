"""
DDS Middleware Python Bindings

基于 CycloneDDS-CXX 的 DDS 中间件 Python 绑定库
"""

import os
import ctypes

# 在导入主模块之前，预先加载 .libs 目录下的所有依赖库
# 这确保动态链接器能找到所有依赖，无需修改 LD_LIBRARY_PATH
_pkg_dir = os.path.dirname(os.path.abspath(__file__))
_libs_dir = os.path.join(_pkg_dir, ".libs")
if os.path.isdir(_libs_dir):
    for _lib_name in sorted(os.listdir(_libs_dir)):
        if _lib_name.endswith(".so") or ".so." in _lib_name:
            _lib_path = os.path.join(_libs_dir, _lib_name)
            try:
                ctypes.CDLL(_lib_path, mode=ctypes.RTLD_GLOBAL)
            except OSError:
                pass

from .dds_middleware_python import *

__version__ = "0.1.0"
__all__ = [name for name in dir() if not name.startswith('_')]
